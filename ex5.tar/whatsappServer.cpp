#include <array>
#include <iostream>
#include <stdlib.h>
#include <string>
#include "Server.h"

using namespace std;
int read_data(int s, char *buf, int n) {
    int bcount;
    int br;
    bcount= 0;
    br= 0;
    while (bcount < n) {
        br = (int)read(s, buf, (size_t)n-bcount);
        if (br > 0) {
            bcount += br;
            buf += br;
        }
        if (br < 1) {
            return(-1);
        }
    }
    return(bcount);
}

int main (int argc, char* argv[])
{
    if(argc != 2)
    {
        cout << "Usage: whatsappServer portNum" << endl;
        exit(1);
    }
    int i = atoi(argv[1]);
    Server server = Server();
    int serverSocket = server.create_socket((unsigned short)i);

    fd_set client_fds, read_fds;

    FD_ZERO(&client_fds);
    FD_SET(serverSocket, &client_fds);
    FD_SET(STDIN_FILENO, &client_fds);
    while (true) {
        read_fds = client_fds;
        if (select(FD_SETSIZE, &read_fds, NULL, NULL, NULL) < 0) {
            cout<<"ERROR: select "<<errno<< "." <<endl;

            return -1;
        }

        for (int fd = 0; fd < FD_SETSIZE; ++fd) {
            char buf[256];
            char size[4];
            if (FD_ISSET(fd, &read_fds)) {
                if (fd == STDIN_FILENO) { // EXIT CASE
                    read_data(fd, size, 3);
                    read_data(fd, buf, atoi(size));
                    server.stdinInput();
                } else if (fd == serverSocket) { // new client
                    int connection = server.make_Connection(serverSocket);
                    FD_SET(connection, &client_fds);
                    break;
                } else { // client's msg
                    read_data(fd, size, 3);
                    read_data(fd, buf, atoi(size));
                    server.handleRequest((string)buf, fd, client_fds);
                    break;

                }
            }
            memset(buf, 0, 256);
        }


    }

    return 0;
}