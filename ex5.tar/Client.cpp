#include <iostream>
#include <stdlib.h>
#include <iomanip>
#include <sstream>
#include "Client.h"

Client::Client(string clientName)
{
    name = clientName;
}

int Client::call_socket(char* hostName, unsigned short portNum)
{
    struct sockaddr_in sockaddrIn;
    struct hostent* host;
    int sock;

    if((host = gethostbyname(hostName)) == NULL)
    {
        return -1;
    }
    memset(&sockaddrIn, 0, sizeof(sockaddrIn));
    memcpy((char*)&sockaddrIn.sin_addr, host->h_addr, (size_t)host->h_length);
    sockaddrIn.sin_family = (sa_family_t)host->h_addrtype;
    sockaddrIn.sin_port = htons((u_short)portNum);
    if ((sock = socket(host->h_addrtype, SOCK_STREAM, 0)) < 0)
    {
        return -1;
    }
    if (connect(sock, (struct sockaddr*)&sockaddrIn, sizeof(sockaddrIn)) < 0)
    {
        close(sock);
        return -1;
    }
    fd = sock;
    return sock;
}

string Client::getName()
{
    return name;
}
vector<string> Client::parseCommand(string command)
{
    vector<string> toRet;
    std::string delimiter = " ";

    size_t pos = 0;
    std::string token;
    while ((pos = command.find(delimiter)) != std::string::npos) {
        token = command.substr(0, pos);
        command.erase(0, pos + delimiter.length());
        toRet.push_back(token);
    }
    toRet.push_back(command);
    return toRet;
}
bool Client::isAlphanumeric(string name)
{
    for (unsigned int i = 0; i < name.size(); i++)
    {
        if (!isalnum(name[i]))
        {
            return false;
        }
    }
    return true;
}
string Client::checkValidation(string mission) {
    if (mission.find("create_group") == 0) {
        vector<string> split = parseCommand(mission);
        std::string delimiter = ",";
        if (split.size() < 3) {
            return "ERROR: Invalid input";
        }
        if (!isAlphanumeric(split.at(1))) {
            return "ERROR: failed to create group " + split.at(1);
        }
        size_t pos = 0;
        std::string token;
        while ((pos = split.at(2).find(delimiter)) != std::string::npos) {
            token = split.at(2).substr(0, pos);
            if (!isAlphanumeric(token) || token == split.at(1)) {
                return "ERROR: failed to create group " + split.at(1);
            }
            split.at(2).erase(0, pos + delimiter.length());

        }
        if (!isAlphanumeric(split.at(2))) {
            return "ERROR: failed to create group " + split.at(1);
        }
        return "valid";
    }
    else if (mission.find("send") == 0) {
        vector<string> split = parseCommand(mission);
        if (split.size() < 3) {
            return "ERROR: Invalid input";
        }
        if (!isAlphanumeric(split.at(1))) {
            return "ERROR: failed to send";
        }
        return "valid";
    }
    else if (mission.find("who") == 0) {
        if (mission == "who")
        {
            return "valid";
        }
        return "ERROR: Invalid input";
    }
    else if (mission.find("exit") == 0) {
        if (mission == "exit")
        {
            return "valid";
        }
        return "ERROR: Invalid input";
    }
    else if (mission.find("message") == 0)
    {

        return "valid";
    }
    else
    {
        return "ERROR: Invalid input";
    }
}
int Client::writeToServer(string msg, fd_set client_fds)
{
    string valid = checkValidation(msg);
    if(msg == "bye")
    {
        FD_CLR(fd, &client_fds);
        close(fd);
        exit(0);
    }
    if(valid == "valid")
    {
        if (msg.find("message") == 0)
        {
            msg.erase(0,8);
            vector<string> split = parseCommand(msg);
            stringstream stream;
            stream << setw(3) << setfill('0') << strlen(msg.c_str());
            string s = stream.str();
            msg = s+msg;
            if(write(fd, msg.c_str(), strlen(msg.c_str())) < 0)
            {
                cout<<"ERROR: write "<<errno<< "." <<endl;
                return -1;
            }
            return 0;
        }
        string message = msg;
        msg = name + " " +msg;
        stringstream stream;
        stream << setw(3) << setfill('0') << strlen(msg.c_str());
        string s = stream.str();
        msg = s+msg;
        if(write(fd, msg.c_str(), strlen(msg.c_str())) < 0)
        {
            cout<<"ERROR: write "<<errno<< "." <<endl;
            return -1;
        }
        if(message == "exit")
        {
            FD_CLR(fd, &client_fds);
            close(fd);

            cout<<"Unregistered successfully."<<endl;
            exit(0);
        }
        return 0;
    }
    else
    {
        cout<<valid<< "." <<endl;
        return -1;
    }

}