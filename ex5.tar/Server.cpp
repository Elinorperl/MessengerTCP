#include <algorithm>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <stdlib.h>
#include "Server.h"



    Server::Server() {}

bool compareClients(string client1, string client2) {
    return client1 < client2;
}

int Server::create_socket(unsigned short portnum)
{
    char socketName[MAXHOSTNAME + 1];
    int sock;
    struct sockaddr_in sockaddrIn;
    struct hostent* host;
    gethostname(socketName, MAXHOSTNAME);
    host = gethostbyname(socketName);
    if (host == NULL)
    {
        return  -1;
    }
    memset(&sockaddrIn, 0, sizeof(struct sockaddr_in));
    sockaddrIn.sin_family = (sa_family_t)host->h_addrtype;
    memcpy(&sockaddrIn.sin_addr, host->h_addr, host->h_length);
    sockaddrIn.sin_port = htons(portnum);
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        cout<<"ERROR: socket "<<errno<< "." <<endl;
        return -1;
    }
    sockaddrIn.sin_addr.s_addr = INADDR_ANY;
    if (bind(sock, (struct sockaddr*)&sockaddrIn, sizeof(struct sockaddr_in)) < 0)
    {
        close(sock);
        cout<<"ERROR: bind "<<errno<< "." <<endl;
        return -1;
    }
    listen(sock, 10);
    serverSocket = sock;
    return sock;
}


int Server::make_Connection(int socket)
{
    struct sockaddr_in con;
    int con_lenth = sizeof(con);
    int connection;
    if ((connection = accept(socket,  (struct sockaddr *) &con, (socklen_t *) &con_lenth)) < 0)
    {
        cout<<"ERROR: accept "<<errno<< "." <<endl;
        return -1;
    }
    return connection;
}

void Server::connectNewClient(string name, int fd)
{
    cout << name << " connected." << endl;
    string str =  "Connected Successfully";
    stringstream stream;
    stream << setw(3) << setfill('0') << strlen(str.c_str());
    string s = stream.str();
    str = s + str;
    write(fd, str.c_str(), strlen(str.c_str()));
    if(!(find(clients.begin(), clients.end(), name) != clients.end())) {
        clients.push_back(name);
        nameTofd[name] = fd;
    }
}

void Server::stdinInput()
{
    for(auto i = nameTofd.begin(); i != nameTofd.end(); ++i)
    {
        string str =  "bye";
        stringstream stream;
        stream << setw(3) << setfill('0') << strlen(str.c_str());
        string s = stream.str();
        str = s + str;
        write(i->second, str.c_str(), strlen(str.c_str()));
    }
    close(serverSocket);
    exit(0);

}


vector<string> parseCommand(string command)
{
    vector<string> toRet;
    std::string delimiter = " ";

    size_t pos = 0;
    std::string token;
    while ((pos = command.find(delimiter)) != std::string::npos) {
        token = command.substr(0, pos);
        command.erase(0, pos + delimiter.length());
        toRet.push_back(token);
    }
    toRet.push_back(command);
    return toRet;
}
int Server::handleRequest(string mission, int fd, fd_set &client_fds)
{
    size_t place = mission.find(" ");
    string name = mission.substr(0, place);
    mission.erase(0, place+1);
    if(mission.find("create_group") == 0)
    {
        bool created = true;
        vector<string> split = parseCommand(mission);
        vector<string> names;
        std::string delimiter = ",";

        size_t pos = 0;
        std::string token;
        if(groups.find(split.at(1)) != groups.end())
        {
            created = false;
        }
        while ((pos = split.at(2).find(delimiter)) != std::string::npos) {
            token = split.at(2).substr(0, pos);
            if(!isAlphanumeric(token) || !(find(clients.begin(), clients.end(), token) != clients.end()))
            {
                created = false;
            }
            split.at(2).erase(0, pos + delimiter.length());
            if(!(find(names.begin(), names.end(), token) != names.end()))
            {
                names.push_back(token);
            }
        }
        if(!isAlphanumeric(split.at(2)) || !(find(clients.begin(), clients.end(), split.at(2)) != clients.end())) {
            created = false;
        } else
        {
            names.push_back(split.at(2));

        }
        if(!(find(names.begin(), names.end(), name) != names.end())) {
            names.push_back(name);
        }
        if((create_group(split.at(1), names, name) >= 0) && (created))
        {
            string str = "Group " + split.at(1) + " was created successfully.";
            stringstream stream;
            stream << setw(3) << setfill('0') << strlen(str.c_str());
            string s = stream.str();
            str = s + str;
            write(fd, str.c_str(), strlen(str.c_str()));
        }
        else
        {
            cout<<name<<": ERROR: failed to create group "<< split.at(1) << "." << endl;
            string str = "ERROR: failed to create group " + split.at(1);
            stringstream stream;
            stream << setw(3) << setfill('0') << strlen(str.c_str());
            string s = stream.str();
            str = s + str;
            write(fd, str.c_str(), strlen(str.c_str()));
        }
        return 0;
    }
    else if(mission.find("send") == 0)
    {
        vector<string> split = parseCommand(mission);
        string msg;
        for(unsigned int i = 2; i < split.size(); ++i)
        {
            msg += split.at(i);
            if (i != split.size()-1)
            {
                msg += " ";
            }
        }
        if((send(split.at(1), msg, name)) >= 0)
        {
            string toSend = "Sent successfully.";
            stringstream stream;
            stream << setw(3) << setfill('0') << strlen(toSend.c_str());
            string s = stream.str();
            toSend = s + toSend;
            write(fd, toSend.c_str(), strlen(toSend.c_str()));
            return 0;
        } else
        {
            string toSend = "ERROR: failed to send.";
            stringstream stream;
            stream << setw(3) << setfill('0') << strlen(toSend.c_str());
            string s = stream.str();
            toSend = s + toSend;
            write(fd, toSend.c_str(), strlen(toSend.c_str()));
            return 0;
        }
    }
    else if(mission.find("who") == 0)
    {
        string str = who(name);

        stringstream stream;
        stream << setw(3) << setfill('0') << strlen(str.c_str());
        string s = stream.str();
        str = s + str;
        write(fd, str.c_str(), strlen(str.c_str()));
        return 0;
    }
    else if(mission.find("exit") == 0)
    {
        exitServer(name, client_fds);
        return 0;
    }

    else
    {
        connectNewClient(name, fd);
        return 0;
    }
}




int Server::create_group(string group_name, vector<string> server_name_list, string name)
{
    if (!isAlphanumeric(group_name))
    {
        return -1;
    }
    if(server_name_list.size() > 1)
    {
        bool name_inside = false;
        for(unsigned int i = 0; i < server_name_list.size(); ++i)
        {
            if(server_name_list.at(i) == name)
            {
                name_inside = true;
            }
        }
        if(!name_inside)
        {
            server_name_list.push_back(name);
        }
        groups[group_name] = server_name_list;

        cout <<name<< ": Group " << group_name << " was created successfully." << endl;
        return 0;
    }
    return -1;
}

int Server::send(string name, string msg, string sender)
{

    if (groups.find(name) != groups.end())
    {
        if(groups[name].size() < 2)
        {
            cout << sender << ": ERROR: failed to send " << msg << "to " << name << "." << endl;
            return -1;
        }
        bool is_sender_in = false;
        for(unsigned int j = 0; j < groups[name].size(); ++j)
        {
            if(groups[name].at(j) == sender)
            {
                is_sender_in = true;
            }
        }
        if(!is_sender_in)
        {
            cout << sender << ": ERROR: failed to send " << msg << "to " << name << "." <<endl;
            return -1;
        }
        for(unsigned int i = 0; i < groups[name].size(); ++i)
        {
            if(sender != groups[name].at(i))
            {
                int cur_fd = nameTofd[groups[name].at(i)];
                string toSend = sender + ": " + msg;
                stringstream stream;
                stream << setw(3) << setfill('0') << strlen(toSend.c_str());
                string s = stream.str();
                toSend = s + toSend;
                if (write(cur_fd, toSend.c_str(), strlen(toSend.c_str())) > 0)
                {
                    cout << sender << ": " << msg << " was sent successfully to " << name << "." << endl;
                }
            }
        }
        return 0;

    }
    else if(nameTofd.find(name) != nameTofd.end())
    {
        int cur_fd = nameTofd[name];
        string toSend = sender + ": " + msg;
        stringstream stream;
        stream << setw(3) << setfill('0') << strlen(toSend.c_str());
        string s = stream.str();
        toSend = s + toSend;
        if (write(cur_fd, toSend.c_str(), strlen(toSend.c_str())) > 0)
        {
            cout << sender << ": " << msg << "was sent successfully to " << name << "." << endl;
            return 0;
        }
    }
    else
    {
        cout << sender << ": ERROR: failed to send " << msg << " to " << name << "." << endl;
        return -1;
    }
    return 0;
}

string Server::who(string name)
{
    sort(clients.begin(), clients.end(), compareClients);
    string toReturn;
    for (unsigned int i = 0; i < clients.size(); i++)
    {
        toReturn += clients.at(i);
        if(i < clients.size() - 1)
        {
            toReturn += ",";
        }
    }
    cout<<name<<": Requests the currently connected client names."<<endl;
    return toReturn;
}

bool Server::isAlphanumeric(string name)
{
    for (unsigned int i = 0; i < name.size(); i++)
    {
        if (!isalnum(name[i]))
        {
            return false;
        }
    }
    return true;
}


void Server::exitServer(string name, fd_set &client_fds)
{
    for(auto i = groups.begin(); i != groups.end(); ++i)
    {
        for(unsigned int j = 0; j < i->second.size(); ++j)
        {
            if(i->second.at(j) == name)
            {
                i->second.erase(i->second.begin() + j);
                break;
            }
        }
    }
    auto toRemove = nameTofd.find(name);
    FD_CLR(toRemove->second, &client_fds);
    nameTofd.erase(toRemove);

    cout<<name<<": Unregistered successfully."<<endl;
};





