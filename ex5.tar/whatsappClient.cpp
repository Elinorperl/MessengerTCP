#include <array>
#include <stdlib.h>
#include <iomanip>
#include <sstream>
#include <iostream>
#include "Client.h"


using namespace std;
int read_data(int s, char *buf, int n) {
    int bcount;
    int br;
    bcount= 0;
    br= 0;
    while (bcount < n) {
        br = (int)read(s, buf, (size_t)n-bcount);
        if (br > 0) {
            bcount += br;
            buf += br;
        }
        if (br < 1) {
            return(-1);
        }
    }
    return(bcount);
}

bool isAlphanumeric(string name)
{
    for (unsigned int i = 0; i < name.size(); i++)
    {
        if (!isalnum(name[i]))
        {
            return false;
        }
    }
    return true;
}

int main(int argc, char* argv[])
{
    if(argc != 4)
    {
        cout << "Usage: whatsappClient clientName serverAddress serverPort" << endl;
        exit(1);
    }
    if(!isAlphanumeric(argv[1]))
    {
        cout << "Usage: whatsappClient clientName serverAddress serverPort" << endl;
        exit(1);
    }
    Client client = Client(argv[1]);
    int fd = client.call_socket(argv[2],atoi(argv[3]));
    string msg = client.getName();
    stringstream stream;
    stream << setw(3) << setfill('0') << strlen(msg.c_str());
    string s = stream.str();
    msg = s + msg;
    if (write(fd, msg.c_str(), strlen(msg.c_str())) < 0)
    {
        cout<<"ERROR: write "<<errno<< "." <<endl;
        return -1;
    }
    fd_set client_fds, read_fds;
    FD_ZERO(&client_fds);
    FD_SET(fd, &client_fds);
    FD_SET(STDIN_FILENO, &client_fds);
    while(true)
    {
        read_fds = client_fds;

        if (select(5, &read_fds, NULL, NULL, NULL) < 0) {
            cout<<"ERROR: select "<<errno<< "." <<endl;
            return -1;
        }
        if (FD_ISSET(fd, &read_fds))
        {
            char buf[256];
            char size[4];
            bzero(buf,256);
            bzero(size,4);
            read_data(fd, size, 3);
            read_data(fd, buf, atoi(size));
            if(strcmp(buf, "bye") == 0)
            {
                exit(0);
            }
            cout<<buf<<endl;
            memset(buf, 0, 256);

        } else
        {
            string mission;
            getline(cin, mission);
            client.writeToServer(mission, client_fds);
            mission.clear();
        }


    }

}