#ifndef EX5_CLIENT_H
#define EX5_CLIENT_H


#include <netinet/in.h>
#include <zconf.h>
#include <netdb.h>
#include <cstring>
#include <string>
#include <vector>

using namespace std;

#define MAXHOSTNAME 30

class Client
{
private:
    string name;
    int fd;
public:
    Client(string clientName);
    int call_socket(char* hostName, unsigned short portNum);
    string getName();
    vector<string> parseCommand(string command);
    int writeToServer(string msg, fd_set client_fds);
    bool isAlphanumeric(string name);
    string checkValidation(string mission);
};
#endif //EX5_CLIENT_H
