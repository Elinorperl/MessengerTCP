
#ifndef EX5_SERVER_H
#define EX5_SERVER_H


#include <netinet/in.h>
#include <zconf.h>
#include <netdb.h>
#include <cstring>
#include <vector>
#include <map>
#include "Client.h"

#define MAXHOSTNAME 30

using namespace std;

class Server
{
private:
    int serverSocket;
    vector<string> clients;
    map<string, vector<string>> groups;
    map<string,int> nameTofd;
    bool isAlphanumeric(string name);

public:
    Server();
    int create_socket(unsigned short portnum);
    int make_Connection(int socket);
    int create_group(string group_name, vector<string> server_name_list, string name);
    int send(string name, string msg, string sender);
    string who(string name);
    void exitServer(string name, fd_set &client_fds);
    void connectNewClient(string name, int fd);
    void stdinInput();
    int handleRequest(string mission, int fd, fd_set &client_fds);
};
#endif //EX5_SERVER_H
